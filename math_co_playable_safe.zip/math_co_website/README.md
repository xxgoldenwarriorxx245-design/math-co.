# math.co website starter

This is a responsive, single-page game directory inspired by the layout in your screenshot.

## Run it
Open `index.html` in a browser. Search, category filters, and game cards work locally.

## Important notes
- The page contains a 216-title catalog, but it does not host or copy the games themselves. Game cards open external game pages or a web search for the named title.
- Some titles may be paid, region-restricted, unavailable in a browser, or not playable on every device. Check the destination before publishing.
- This is an original layout inspired by the screenshot, not a copy of the original site's code, logos, or artwork.
- Before making the site public, replace any search-result links with verified official or licensed game URLs, add your own privacy/terms pages, and check the rules of any school or hosting network where it will be used.


## Safety improvements
- Game cards no longer launch directly; a safety reminder appears first.
- The page does not embed third-party games or execute their code inside math.co.
- External destinations open in a separate tab with `noopener,noreferrer`.
- The reminder tells visitors not to share personal information or download unexpected files.

This is a safety aid, not a guarantee that every external game or destination is safe. Review links before publishing and ask a parent/guardian to help choose age-appropriate games. The catalog still includes some titles that may not be appropriate for every age; remove or replace any you don't want to list.
